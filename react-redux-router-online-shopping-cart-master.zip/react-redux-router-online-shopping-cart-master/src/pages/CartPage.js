import React from 'react'
import Cart from '../features/Cart'

const CartPage = props => (
  <div>
    <h2>Cart page</h2>
    <Cart />
  </div>
)

export default CartPage